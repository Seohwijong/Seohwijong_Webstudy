package com.sist.vo;

public class FoodVO {
private int fdno;
private String title,poster,address,tel,type,price,parking,menu,rday,time;
private Double score;
public int getFdno() {
	return fdno;
}
public void setFdno(int fdno) {
	this.fdno = fdno;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getPoster() {
	return poster;
}
public void setPoster(String poster) {
	this.poster = poster;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getTel() {
	return tel;
}
public void setTel(String tel) {
	this.tel = tel;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public String getParking() {
	return parking;
}
public void setParking(String parking) {
	this.parking = parking;
}
public String getMenu() {
	return menu;
}
public void setMenu(String menu) {
	this.menu = menu;
}
public String getRday() {
	return rday;
}
public void setRday(String rday) {
	this.rday = rday;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public Double getScore() {
	return score;
}
public void setScore(Double score) {
	this.score = score;
}

}
